import os
import sys
import shutil
import argparse
import subprocess
from distutils.file_util import move_file
from typing import Union

def parse_arguments():
    parser = argparse.ArgumentParser(description=" 自动构建脚本")

   # 添加参数
    parser.add_argument("--sys",
                        type=str,
                        default="win",
                        choices=["win", "ohos", "mac", "linux"],
                        help="目标系统 使用方式  --sys win")
    parser.add_argument("--build_type",
                        type=str,
                        default="Release",
                        choices=["Debug", "Release"],
                        help="目标类型 使用方式  --build_type Release")

    parser.add_argument("--env_config",
                        type=str,
                        default="prod",
                        choices=["dev", "prod"],
                        help="配置环境，默认使用生产环境的配置 使用方式  --env_config prod")   

    parser.add_argument("--arch",
                        type=str,
                        default="x86",
                        choices=["x86", "x64"],
                        help="目标架构 使用方式  --arch x86")
    parser.add_argument("--thr_path",
                        type=str,
                        default="C:/dzh",
                        help=" 第三方库路径 使用方式  --thr_path C:/dzh_libs/win_libs")

    parser.add_argument("--cmake_path",
                        type=str,
                        default="D:/Qt5.15.2/Tools/CMake_64/bin/cmake.exe",
                        help=" cmake路径 使用方式  --cmake_path D:/App/CMake/bin/cmake.exe")

    parser.add_argument("--qt_sdk_path",
                        type=str,
                        default="D:/Qt5.15.2/5.15.2/msvc2019",
                        help=" qt sdk路径 使用方式  --qt_sdk_path D:/Qt/Qt5.15.2/5.15.2/msvc2019")
    parser.add_argument("--ninja_path",
                        type=str,
                        default="D:/Qt5.15.2/Tools/Ninja/ninja.exe",
                        help=" ninja路径 使用方式  --ninja_path D:/Qt/Qt5.15.2/Tools/Ninja/ninja.exe")
    parser.add_argument("--llvm_path",
                        type=str,
                        default="D:/LLVM/LLVM32/bin",
                        help=" llvm bin路径 使用方式  --llvm_path D:/App/LLVM32/bin")                                             
    parser.add_argument("--win_kits_path",
                        type=str,
                        default=r"C:/Program Files (x86)/Windows Kits/10/bin/10.0.19041.0",
                        help=" windows kits路径配置 使用方式  --win_kits_path C:/Program Files (x86)/Windows Kits/10/bin/10.0.19041.0")

    parser.add_argument("--dist_path",
                        type=str,
                        default="D:/workspace/dzh-build/Stock",
                        help=" 项目构建输出路径 使用方式  --dist_path E:/DZHStock")
 

    parser.add_argument("--dealer_id",
                        type=str,
                        default="8888",
                        help=" 券商id配置文件 使用方式  --dealer_id 8888")


    parser.add_argument("--plugins",
                        type=str,
                        default="Login",
                        help="生成库文件 到 项目路径 下的 plugins 文件夹下 (逗号分隔)(默认全选) 使用方式  --plugins Login,LoginOhos")


    parser.add_argument("--projects",
                        type=str,
                        default="Tool,Data,ThreadPool,TcpParser,Dispatch,HTTPParser,Widget,Login",
                        help="项目列表(逗号分隔)(默认全选) 先后顺序不可更改,但可以单独编译某几项 使用方式  --projects Tool,Data,ThreadPool,TcpParser,Dispatch,HTTPParser,Widget,Login,Main")

    parser.add_argument("--build_main",
                        type=str,
                        default="Main",
                        help="项目列表(逗号分隔)(默认全选) 先后顺序不可更改,但可以单独编译某几项 使用方式  --build_exe TradeMain,Main")


    return parser.parse_args()


class BuildConfig:
    """构建配置参数管理类"""
    def __init__(self, args):
        """
        初始化构建配置。
        :param args: argparse.Namespace，命令行参数
        """
        print("-----当前构建参数配置：----")
        args_dict = vars(args)
        max_len = max(len(k) for k in args_dict.keys()) + 1  # +1 增加间距
        for k, v in args_dict.items():
            print(f"  {k.ljust(max_len)} = {v}")

        self.args = args

        # 父节点
        os.chdir("../")

    def get_cmake_configure(self) :
        """
        生成 CMake 配置命令参数列表，确保参数灵活且安全。
        :return: list[str]，CMake 配置参数
        """
        # 将相对路径转为绝对路径，保证输出路径一致性
        self.args.dist_path = os.path.abspath(self.args.dist_path).replace("\\", "/")
        _args = [
            self.args.cmake_path,
            '-G', 'Ninja',
            '-B', 'out',
            '-S', '.',
            f'-DBUILD_SYSTEM={self.args.sys}',
            f'-DCMAKE_BUILD_TYPE={self.args.build_type}',
            f'-DBUILD_ARCH={self.args.arch}',
            f'-DCMAKE_MAKE_PROGRAM={self.args.ninja_path}',
            f'-DCMAKE_PREFIX_PATH={self.args.qt_sdk_path}',
            f'-DCMAKE_CXX_COMPILER={self.args.llvm_path}/clang-cl.exe',
            f'-DCMAKE_C_COMPILER={self.args.llvm_path}/clang-cl.exe',
            f'-DCMAKE_LINKER={self.args.llvm_path}/lld-link.exe',
            f'-DCMAKE_RC_COMPILER={self.args.llvm_path}/llvm-rc.exe',
            f'-DTHR_PATH={self.args.thr_path}',
            f'-DDIST_PATH={self.args.dist_path}',
        ]
        return _args

    def get_cmake_build(self) :
        """
        生成 CMake 构建命令参数列表。
        :return: list[str]，CMake 构建参数
        """
        # return [self.args.cmake_path, '--build', 'out', '-v']
        return [self.args.cmake_path, '--build', 'out']

    def get_projects(self) -> list:
        """ 构建 列表"""
        """安全获取构建项目列表（自动过滤空格和空项）"""
        return [p.strip() for p in self.args.projects.split(",") if p.strip()]

    def get_plugins(self) -> list:
        """ 构建 列表"""
        """安全获取构建项目列表（自动过滤空格和空项）"""
        return [p.strip().lower() for p in self.args.plugins.split(",") if p.strip()]

    def copy_header_files(self,src_dir, dest_dir):
        """
        遍历 src_dir 及其子目录，搜索 .h 文件，并将其拷贝到 dest_dir 中，同时保留原始目录结构。

        :param src_dir: 源目录
        :param dest_dir: 目标目录
        """
        for root, dirs, files in os.walk(src_dir):
            for file in files:
                if file.endswith('.h'):
                    # 获取源文件的完整路径
                    src_file_path = os.path.join(root, file)
                    # 计算目标文件的路径，保留原始目录结构
                    relative_path = os.path.relpath(root, src_dir)
                    dest_file_dir = os.path.join(dest_dir, relative_path)
                    dest_file_path = os.path.join(dest_file_dir, file)

                    # 创建目标目录（如果不存在）
                    os.makedirs(dest_file_dir, exist_ok=True)

                    # 拷贝文件
                    shutil.copy2(src_file_path, dest_file_path)
                    # print(f"Copied: {src_file_path} -> {dest_file_path}")


    def copy_files(self,src_dir: Union[str, os.PathLike], dest_dir: Union[str, os.PathLike],suffix=(),no_suffix=()):
        """
        复制指定目录下的所有库文件到目标目录
        :param src_dir: 源目录（需要搜索库文件的目录）
        :param dest_dir: 目标目录（存放库文件的目录）
        :param suffix: 文件后缀
        """
        if not os.path.exists(dest_dir):
            os.makedirs(dest_dir, exist_ok=True)

        for root, dirs, files in os.walk(src_dir):
            for file in files:
                if file.endswith(suffix) and not file.endswith(no_suffix):
                    src_path = str(os.path.join(root, file))
                    dst_path = str(os.path.join(dest_dir, file))
                    shutil.copy2(src_path, dst_path)
                    print(f"Copied libs: {src_path} -> {dst_path}")

    def copy_all_contents(self, src_dir, dest_dir, suffix=(),no_suffix=(),no_folder=()):
        """
        递归拷贝整个目录结构及所有内容（包含子文件夹和文件）

        :param src_dir:   源目录（需要复制的根目录）
        :param dest_dir:  目标目录（复制内容将存放到这里）
        :param suffix:   需要复制的文件后缀列表
        :param no_suffix:   不需要复制的文件后缀列表
        :param no_folder: 不需要复制的文件夹
        """
        for root, dirs, files in os.walk(src_dir):
            # 过滤不需要的目录（关键修改点）
            dirs[:] = [d for d in dirs if d not in no_folder]
            # 处理目录结构
            for dir_name in dirs:
                src_dir_path = os.path.join(root, dir_name)
                relative_path = os.path.relpath(src_dir_path, src_dir)
                dest_dir_path = os.path.join(dest_dir, relative_path)
                os.makedirs(dest_dir_path, exist_ok=True)

            # 处理文件
            for file in files:
                src_file_path = os.path.join(root, file)
                relative_path = os.path.relpath(root, src_dir)
                dest_file_dir = os.path.join(dest_dir, relative_path)
                dest_file_path = os.path.join(dest_file_dir, file)

                # shutil.copytree()
                # 过滤满足条件的 dll
                if file.endswith(suffix) and not file.endswith(no_suffix):
                    shutil.copy2(src_file_path, dest_file_path)
                    print(f"Copied libs: {src_file_path} -> {dest_file_path}")

                elif not file.endswith(suffix) and not file.endswith(no_suffix):
                    # 两个都不是满足条件 非库文件 直接拷贝
                    shutil.copy2(src_file_path, dest_file_path)
                    print(f"Copied libs----: {src_file_path} -> {dest_file_path}")

    def copy_all_files(self, src_dir, dest_dir):
        """
        拷贝 文件 和 子文件夹
        :param src_dir:   源目录（需要复制的根目录）
        :param dest_dir:  目标目录（复制内容将存放到这里）
        """
        shutil.copytree(src_dir, dest_dir, symlinks=False, ignore=None, copy_function=shutil.copy2, ignore_dangling_symlinks=False, dirs_exist_ok=True)


    def copy_thr_libs_files(self):
        """ 拷贝第三方库 到 指定项目文件夹中 """
        _dist_path = self.args.dist_path
        _plugins = self.get_plugins()
        _plugin_path = os.path.join(str(_dist_path), "plugins")
        if not os.path.exists(_plugin_path):
            os.makedirs(_plugin_path, exist_ok=True)

        # 拷贝到  项目 plugins 目录
        _plugin_files=[]
        for item in _plugins:
            _plugin_files.append(os.path.join(item.lower(),"bin", self.args.arch).lower())

        _plugin_tuple = tuple(_plugin_files)

        suffix=".dll"
        no_suffix=("d.dll",".pdb",".qrc")
        if self.args.build_type.lower() == "debug":
            suffix=("d.dll",".pdb")
            no_suffix=(".qrc")

        # 添加特殊处理 如果存在 debug:release 优先拷贝该文件夹下的内容  例如 bin/x86:x64/debug:release/*.*
        _sp_path = os.path.join("bin", self.args.arch, self.args.build_type).lower()

        _tmp_path = os.path.join("bin", self.args.arch).lower()

        for root, dirs, files in os.walk(self.args.thr_path):
            # 判断是否在目标路径范围内
            _sp_dir = os.path.join(root,_sp_path).lower()
            _tmp_dir = os.path.join(root,_tmp_path).lower()

            is_flag = False
            for _dir in _plugin_files:
                _p_dir = os.path.join(root,_dir).lower()
                if os.path.exists(_p_dir):
                    print(f"拷贝到plugins：{root} -> {_dist_path}")
                    self.copy_files(_p_dir, _plugin_path, suffix,no_suffix)
                    is_flag = True

            if is_flag:
                continue

            if os.path.exists(_sp_dir):
                print(f"拷贝特殊处理：{root} -> {_dist_path}")
                self.copy_all_files(_sp_dir,_dist_path)

            elif os.path.exists(_tmp_dir) and not os.path.exists(_sp_dir):
                print(f"拷贝第三方库：{root} -> {_dist_path}")
                self.copy_files(_tmp_dir, _dist_path, suffix,no_suffix)

    def copy_config_files(self):
        """ 拷贝 配置文件 到 指定项目文件夹中 """
        _dist_path = os.path.join(self.args.dist_path, "config")
        if not os.path.exists(_dist_path):
            os.makedirs(_dist_path, exist_ok=True)

        # 获取当前工作目录下的 Config 文件夹路径
        _config_path = os.path.join(os.getcwd(), "Config",self.args.dealer_id, self.args.env_config)

        if os.path.exists(_config_path):
            self.copy_all_files(_config_path,_dist_path)
            print(f"配置文件拷贝：{_config_path} -> {_dist_path}")
        else:
            print(f"配置文件不存在 {_config_path} ")

    def build_main(self):
        """
        Windows 平台的构建流程。
        """
        # 设置环境变量，确保 mt.exe 能被找到
        env = os.environ.copy()
        mt_dir = os.path.join(self.args.win_kits_path, self.args.arch)
        env["PATH"] = mt_dir + os.pathsep + env["PATH"]

        _cmake_args = self.get_cmake_configure()
        _cmake_build_args = self.get_cmake_build()
        _projects = self.get_projects()
        _project_path = os.path.join(self.args.thr_path , "project")

        print("--------------CMake----------------------")
        print(f"CMake configure:{_cmake_args}")
        print(f"CMake build:{_cmake_build_args}")

        if os.path.exists(self.args.build_main):
            print(f"======================= {self.args.build_main} Project 构建开始 =======================")

            # 编译输出路径
            source_dir = os.path.join(os.getcwd(), self.args.build_main,  "out")
            self.clean_output_dir(source_dir)

            ret = subprocess.run(_cmake_args, env=env, cwd=self.args.build_main)
            if ret.returncode != 0:
                raise RuntimeError(f"CMake configure failed in {self.args.build_main}")

            ret = subprocess.run(_cmake_build_args, env=env, cwd=self.args.build_main)
            if ret.returncode != 0:
                raise RuntimeError(f"CMake build failed in {self.args.build_main}")
            print(f"=======================   Project 构建结束 =======================")

            self.clean_output_dir(source_dir)
        else:
            raise RuntimeError(f"不存在 {self.args.build_main} 项目, 退出构建")

    def build_projects(self):
        """
        构建项目（Windows 平台）
        """
        # 设置环境变量，确保 mt.exe 能被找到
        env = os.environ.copy()
        mt_dir = os.path.join(self.args.win_kits_path, self.args.arch)
        env["PATH"] = mt_dir + os.pathsep + env["PATH"]

        # 生成 CMake 配置和构建命令
        _cmake_args = self.get_cmake_configure()
        _cmake_build_args = self.get_cmake_build()
        _projects = self.get_projects()
        _project_path = os.path.join(self.args.thr_path , "project")

        print("--------------CMake----------------------")
        print(f"CMake configure:{_cmake_args}")
        print(f"CMake build:{_cmake_build_args}")

        for item in _projects:
            if os.path.exists(item):
                print(f"======================= {item} Project 构建开始 =======================")

                # 编译输出路径
                source_dir = os.path.join(os.getcwd(), item,  "out")
                self.clean_output_dir(source_dir)

                ret = subprocess.run(_cmake_args, env=env, cwd=item)
                if ret.returncode != 0:
                    raise RuntimeError(f"CMake configure failed in {item}")

                ret = subprocess.run(_cmake_build_args, env=env, cwd=item)
                if ret.returncode != 0:
                    raise RuntimeError(f"CMake build failed in {item}")
                print(f"=======================   Project 构建结束 =======================")

                print(f"===================拷贝 {item} 库 开始=======================")

                # 拷贝到 库 bin目录
                bin_path = os.path.join(_project_path, item.lower(), "bin", self.args.arch)
                self.copy_files(source_dir, bin_path,suffix=(".so", ".dll", ".dylib"))
                # 拷贝到 库 lib目录
                libs_path = os.path.join(_project_path, item.lower(), "lib", self.args.arch)
                self.copy_files(source_dir, libs_path,suffix=(".so", ".lib", ".dylib"))

                print(f"===================拷贝 {item} 库 结束 =======================")
                # 清理输出目录
                self.clean_output_dir(source_dir)
                print(f"===================拷贝 {item} include 头文件 开始 =======================")
                subproject_dir = os.path.join(os.getcwd(), item)
                _subproject_include_path = os.path.join(_project_path, item.lower(), "include")
                self.copy_header_files(subproject_dir, _subproject_include_path)
                print(f"===================拷贝 {item} include 头文件 结束 =======================")
            else:
                raise RuntimeError(f"不存在 {item} 项目, 退出构建")

    def clean_output_dir(self, _dir):
        """ 删除输出目录 """
        if os.path.exists(_dir):
            print(f"===================删除  {_dir} 文件夹 =======================")
            shutil.rmtree(_dir, ignore_errors=False, onerror=lambda func, path, _: (print(f"删除失败: {path}"), os.chmod(path, 0o777), func(path)))


    def copy_trade_file(self):
        """ 拷贝交易文件 """

        suffix=".dll"
        no_suffix="d.dll"
        if self.args.build_type.lower() == "debug":
            suffix=("d.dll",".pdb")
            no_suffix=""
        print(f"----------------------------- 拷贝 资源文件 到 Main项目中 ---------------------------")


        # 拷贝 库文件 到 输出目录
        _lib_path = os.path.join(self.args.thr_path, "trade", "bin", self.args.arch)
        _dist_path = self.args.dist_path

        if not os.path.exists(_lib_path) :
            raise RuntimeError(f"不存在交易 库文件 ${_lib_path}")


        if not os.path.exists(_dist_path):
            os.makedirs(_dist_path, exist_ok=True)

        print(f"----------------------------- 拷贝 库文件 到 输出目录 ---------------------------")
        self.copy_files(_lib_path, _dist_path, suffix,no_suffix)

        print(f"----------------------------- 拷贝 cfg资源文件 到 输出目录 ---------------------------")
        # 拷贝 cfg资源文件 到 输出目录
        _dist_cfg_path = str(os.path.join(self.args.dist_path,"config"))

        _cfg_path = os.path.join(self.args.thr_path, "trade", "cfg")
        if not os.path.exists(_dist_cfg_path):
            os.makedirs(_dist_cfg_path, exist_ok=True)

        if not os.path.exists(_cfg_path) :
            raise RuntimeError(f"不存在交易 cfg 文件 ${_cfg_path}")

        self.copy_all_files(_cfg_path, _dist_cfg_path)



if __name__ == "__main__":
    try:
        args = parse_arguments()

        config = BuildConfig(args)

        if args.sys == "win":
            print(f"----------------------------- 拷贝 交易库 到项目 ---------------------------")
            # config.copy_trade_file()
            print(f"----------------------------- 构建 项目 ---------------------------")
            config.build_projects()
            print(f"----------------------------- 构建 主项目 ---------------------------")
            # config.build_main()
            print(f"----------------------------- 拷贝第三方库到项目 ---------------------------")
            config.copy_thr_libs_files()
            print(f"构建 拷贝配置到项目--------------------------------------------------------")
            config.copy_config_files()
            print(f"构建 结束--------------------------------------------------------")
        else:
            print(f"暂不支持的系统类型: {args.sys}")
    except Exception as e:
        print(f"Error: {e}")
        sys.exit(1)


