import os
import sys
import shutil
import argparse
from typing import Union
import subprocess
import re
import json5

def parse_arguments():
    parser = argparse.ArgumentParser(description="DZHStock 构建脚本")

    # 添加参数
    parser.add_argument("--sys",
                        type=str,
                        default="ohos",
                        choices=["ohos"],
                        help="目标系统 使用方式  --sys ohos")

    parser.add_argument("--build_type",
                        type=str,
                        default="hap",
                        choices=["hap","app"],
                        help="构建类型 使用方式  --build hap")

    parser.add_argument("--env_config",
                        type=str,
                        default="prod",
                        choices=["dev", "prod"],
                        help="配置环境，默认使用生产环境的配置 使用方式  --env_config prod")

    parser.add_argument("--arch",
                        type=str,
                        default="ohos",
                        choices=["ohos"],
                        help="目标架构 使用方式  --arch ohos")

    parser.add_argument("--product",
                        type=str,
                        default="8888_dzh_debug",
                        choices=["8888_dzh_debug","8888_dzh"],
                        help="构建类型 使用方式  --product 8888_dzh_debug")

    parser.add_argument("--thr_path",
                        type=str,
                        default="C:/dzh",
                        help=" 第三方库路径 使用方式  --thr_path C:/dzh")

    parser.add_argument("--ohos_sdk_path",
                        type=str,
                        default="D:/App/Huawei/ohos_sdk/15",
                        help=" ohos sdk 使用方式  --ohos_sdk_path D:/App/Huawei/ohos_sdk/15")
    parser.add_argument("--deveco_studio",
                        type=str,
                        default=r"D:/App/Huawei/DevEcoStudio509R",
                        help=" deveco_studio 路径 使用方式  --ohos_sdk_path D:/App/Huawei/DevEcoStudio509R")

    parser.add_argument("--qt_sdk_path",
                        type=str,
                        default="C:/ohos/0604/ohos_arm64-v8a",
                        help=" qt sdk 使用方式  --qt_sdk_path C:/ohos/ohos16_arm64-v8a")

    parser.add_argument('--java_home', 
                        type=str, 
                        default='D:/Huawei/DevEcoStudio/jbr',
                        help='Java JDK 安装路径 --java_home D:/Huawei/DevEcoStudio/jbr')

    parser.add_argument("--dist_path",
                        type=str,
                        default="E:/DZHStock/Ohos",
                        help=" 项目路径 使用方式  --dist_path E:/DZHStock/Ohos")

    parser.add_argument("--dealer_id",
                        type=str,
                        default="8888",
                        help=" 券商id配置文件 (默认: 8888 ) 使用方式  --dealer_id 8888")

    parser.add_argument("--plugins",
                        type=str,
                        default="Login",
                        help="生成库文件 到 项目路径 下的 plugins 文件夹下 (逗号分隔)(默认全选) 使用方式  --plugins Login,LoginOhos")


    parser.add_argument("--projects",
                        type=str,
                        default="Tool,Data,ThreadPool,TcpParser,Dispatch,HTTPParser,Widget,Login",
                        help="项目列表(逗号分隔)(默认全选) 先后顺序不可更改,但可以单独编译某几项 使用方式  --projects Tool,Data,ThreadPool,TcpParser,Dispatch,HTTPParser,Widget,Login")


    return parser.parse_args()

def find_case_insensitive_dir(parent_dir, target_name):
    for name in os.listdir(parent_dir):
        full_path = os.path.join(parent_dir, name)
        if os.path.isdir(full_path) and name.lower() == target_name.lower():
            return name
    return target_name  # 如果没找到，返回原始名

class BuildConfig:
    """构建配置参数管理类"""
    def __init__(self, args):
        """
        初始化构建配置。
        :param args: argparse.Namespace，命令行参数
        """
        print("-----当前构建参数配置：----")

        args_dict = vars(args)
        max_len = max(len(k) for k in args_dict.keys()) + 1  # +1 增加间距
        for k, v in args_dict.items():
            print(f"  {k.ljust(max_len)} = {v}")

        # 基础参数
        self.args = args

        # 父节点
        os.chdir("../")

        current_dir = os.getcwd()
        real_dir_name = find_case_insensitive_dir(current_dir, "ohosproject")
        self.args.ohos_project = os.path.join(current_dir, real_dir_name)

        print(f"构建 结束----------------{self.args.ohos_project}----------------------------------------")
    def get_cmake_configure(self):
        """
        生成 CMake 配置命令参数列表，确保参数灵活且安全。
        :return: list[str]，CMake 配置参数
        """
        _args = [
            f'{self.args.ohos_sdk_path}/native/build-tools/cmake/bin/cmake.exe',
            '-G', 'Ninja',
            '-B', 'out',
            '-S', '.',
            f'-DBUILD_SYSTEM={self.args.sys}',
            f'-DCMAKE_MAKE_PROGRAM={self.args.ohos_sdk_path}/native/build-tools/cmake/bin/ninja.exe',
            f'-DCMAKE_PREFIX_PATH={self.args.qt_sdk_path}',
            f'-DCMAKE_TOOLCHAIN_FILE={self.args.ohos_sdk_path}/native/build/cmake/ohos.toolchain.cmake',
            f'-DCMAKE_CXX_COMPILER={self.args.ohos_sdk_path}/native/llvm/bin/clang++.exe',
            f'-DCMAKE_C_COMPILER={self.args.ohos_sdk_path}/native/llvm/bin/clang.exe',
            f'-DTHR_PATH={self.args.thr_path}',
            f'-DDIST_PATH={self.args.dist_path}',
            f'-DBUILD_ARCH={self.args.arch}',
        ]

        return _args
    def get_cmake_build(self):
        """
        生成 CMake 构建命令参数列表。
        :return: list[str]，CMake 构建参数
        """
        _args = [
            f'{self.args.ohos_sdk_path}/native/build-tools/cmake/bin/cmake.exe',
            '--build', 'out'
        ]
        return _args

    def get_ohos_build_clean_configure(self):
        """获取 鸿蒙  构建 清理项目"""

        return f" {self.args.deveco_studio}/tools/node/node.exe {self.args.deveco_studio}/tools/hvigor/bin/hvigorw.js -p product={self.args.product} clean --analyze=normal --parallel --incremental --daemon "
      

    def get_ohos_ohpm_configure(self):
        """获取 鸿蒙  构建安装 module """
        return f" {self.args.deveco_studio}/tools/node/node.exe {self.args.deveco_studio}/tools/ohpm/bin/pm-cli.js install --all --registry https://ohpm.openharmony.cn/ohpm/ --strict_ssl true "
        

    def get_ohos_build_hap_configure(self):
        """获取 鸿蒙  构建 编译 hap """
        return f" {self.args.deveco_studio}/tools/node/node.exe {self.args.deveco_studio}/tools/hvigor/bin/hvigorw.js --mode module -p product={self.args.product} -p buildMode=debug assembleHap --analyze=normal --parallel --incremental --daemon"
       
    def get_ohos_build_app_configure(self):
        """获取 鸿蒙  构建 编译 app """
        return f" {self.args.deveco_studio}/tools/node/node.exe {self.args.deveco_studio}/tools/hvigor/bin/hvigorw.js --mode project -p product={self.args.product} -p buildMode=release assembleApp --analyze=normal --parallel --incremental --daemon"
       

    def get_projects(self) -> list:
        """ 构建 列表"""
        """安全获取构建项目列表（自动过滤空格和空项）"""
        return [p.strip() for p in self.args.projects.split(",") if p.strip()]

    def get_plugins(self) -> list:
        """ 构建 列表"""
        """安全获取构建项目列表（自动过滤空格和空项）"""
        return [p.strip().lower() for p in self.args.plugins.split(",") if p.strip()]

    def copy_header_files(self,src_dir: Union[str, os.PathLike], dest_dir: Union[str, os.PathLike]):
        """
        遍历 src_dir 及其子目录，搜索 .h 文件，并将其拷贝到 dest_dir 中，同时保留原始目录结构。

        :param src_dir: 源目录
        :param dest_dir: 目标目录
        """
        for root, dirs, files in os.walk(src_dir):
            for file in files:
                if file.endswith('.h'):
                    # 获取源文件的完整路径
                    src_file_path = str(os.path.join(root, file))
                    # 计算目标文件的路径，保留原始目录结构
                    relative_path = os.path.relpath(root, src_dir)
                    dest_file_dir = os.path.join(dest_dir, relative_path)
                    dest_file_path = str(os.path.join(dest_file_dir, file))

                    # 创建目标目录（如果不存在）
                    os.makedirs(dest_file_dir, exist_ok=True)

                    # 拷贝文件
                    shutil.copy2(src_file_path, dest_file_path)
                    # print(f"Copied: {src_file_path} -> {dest_file_path}")

    def copy_all_contents(self, src_dir, dest_dir, without=[]):
        """
        递归拷贝整个目录结构及所有内容（包含子文件夹和文件）
        :param src_dir: 源目录（需要复制的根目录）
        :param dest_dir: 目标目录（复制内容将存放到这里）
        :param without: 不包含目录 (不复制这些目录)
        """
        if without is None:
            without = []
        for root, dirs, files in os.walk(src_dir):
            # 过滤不需要的目录（关键修改点）
            dirs[:] = [d for d in dirs if d not in without]

            # 处理目录结构
            for dir_name in dirs:
                src_dir_path = os.path.join(root, dir_name)
                relative_path = os.path.relpath(src_dir_path, src_dir)
                dest_dir_path = os.path.join(dest_dir, relative_path)
                os.makedirs(dest_dir_path, exist_ok=True)

            # 处理文件
            for file_name in files:
                src_file_path = os.path.join(root, file_name)
                relative_path = os.path.relpath(root, src_dir)
                dest_file_dir = os.path.join(dest_dir, relative_path)
                dest_file_path = os.path.join(dest_file_dir, file_name)
                shutil.copy2(src_file_path, dest_file_path)

    def copy_thr_libs_files(self):
        """ 拷贝第三方库 到 指定项目文件夹中 """
        _dist_path = os.path.join(self.args.ohos_project, "entry/libs/arm64-v8a")
        if not os.path.exists(_dist_path):
            os.makedirs(_dist_path, exist_ok=True)

        for root, dirs, files in os.walk(self.args.thr_path):
            # 判断是否在目标路径范围内
            if root.lower().endswith("lib"):
                for root, dirs, files in os.walk(root):
                    for file in files:
                        src_path = str(os.path.join(root, file))
                        dst_path = str(os.path.join(_dist_path, file))
                        #  匹配以.so结尾，后面可能跟随.数字的部分
                        if re.search(r"\.so(\.\d+)*$" ,file):
                            shutil.copy2(src_path, dst_path)
                            print(f"Copied libs: {src_path} -> {dst_path}")

    def copy_config_files(self):
        """ 拷贝 配置文件 到 指定项目文件夹中 """
        _dist_path = os.path.join(self.args.ohos_project,"entry/src/main/resources/rawfile/config").lower()
        if not os.path.exists(_dist_path):
            os.makedirs(_dist_path, exist_ok=True)

        # 获取当前工作目录下的 Config 文件夹路径
        _config_path = os.path.join(os.getcwd(), "Config",self.args.dealer_id, self.args.env_config)

        if os.path.exists(_config_path):
            self.copy_all_contents(_config_path,_dist_path)
            print(f"配置文件拷贝：{_config_path} -> {_dist_path}")
        else:
            print(f"配置文件不存在 {_config_path} ")

    def build_ohos_projects(self):

        # 设置环境变量，
        env = os.environ.copy()

        _cmake_args = self.get_cmake_configure()
        _cmake_build_args = self.get_cmake_build()
        _projects = self.get_projects()
        _project_path = os.path.join(self.args.thr_path , "project")
        _plugins = self.get_plugins()

        _dist_path = str(os.path.join(self.args.ohos_project,"entry/libs/arm64-v8a"))
        _plugin_path = os.path.join(_dist_path, "plugins")
        if not os.path.exists(_plugin_path):
            os.makedirs(_plugin_path, exist_ok=True)

        print("--------------CMake----------------------")
        print(f"CMake configure:{_cmake_args}")
        print(f"CMake build:{_cmake_build_args}")

        print(f"-_projects--{_projects}")
        for item in _projects:

            res = os.path.exists(item)
            if os.path.exists(item):
                print(f"======================= {item} Project 构建开始 =======================")
                # 编译输出路径
                source_dir = os.path.join(os.getcwd(), item,  "out")
                self.clean_output_dir(source_dir)

                ret = subprocess.run(_cmake_args, env=env, cwd=item)
                if ret.returncode != 0:
                    raise RuntimeError(f"CMake configure failed in {item}")

                ret = subprocess.run(_cmake_build_args, env=env, cwd=item)
                if ret.returncode != 0:
                    raise RuntimeError(f"CMake build failed in {item}")
                print(f"=======================   Project 构建结束 =======================")

                print(f"===================拷贝 {item} 库 开始=======================")

                # 拷贝到  项目 目录
                dist_path = _dist_path
                if item.lower() in _plugins:
                    dist_path = _plugin_path

                print(f"=================输出目录 {dist_path}==================")
                self.copy_files(source_dir, dist_path,post_fix=(".so", ".dll", ".dylib"))

                # 拷贝到 库 目录
                libs_path = os.path.join(_project_path, item.lower(), "lib", self.args.arch)
                self.copy_files(source_dir, libs_path,post_fix=(".so", ".lib", ".dylib"))
                print(f"===================拷贝 {item} 库 结束 =======================")

                self.clean_output_dir(source_dir)

                print(f"===================拷贝 {item} include 头文件 开始 =======================")
                subproject_dir = os.path.join(os.getcwd(), item)
                _subproject_include_path = os.path.join(_project_path, item.lower(), "include")
                self.copy_header_files(subproject_dir, _subproject_include_path)
                print(f"===================拷贝 {item} include 头文件 结束 =======================")
            else:
                raise RuntimeError(f"不存在 {item} 项目, 退出构建")

    def ohos_change_build_profile(self):
        """ 修改 ohos 构建的 build-profile.json5 buildOption/externalNativeOptions/arguments 的构建参数"""

     
        _new_args = f" -DCMAKE_PREFIX_PATH={self.args.qt_sdk_path} -DBUILD_ARCH={self.args.arch} -DBUILD_SYSTEM={self.args.sys} -DTHR_PATH={self.args.thr_path} -DDIST_PATH={self.args.dist_path}"
        _str_args = str(_new_args)
        _build_profile_path = os.path.join(self.args.ohos_project, "entry/build-profile.json5")

        if os.path.exists(_build_profile_path):
            try:
                with open(_build_profile_path, 'r', encoding='utf-8') as file:
                    data = json5.load(file)
                # 定位到 buildOption/externalNativeOptions/arguments

                # 定位到需要修改的节点
                build_option = data.get('buildOption', {})
                external_native = build_option.get('externalNativeOptions', {})

                # 更新数据结构
                external_native['arguments'] = _str_args
                build_option['externalNativeOptions'] = external_native
                data['buildOption'] = build_option
                # 写回数据
                with open(_build_profile_path, 'w', encoding='utf-8') as file:
                    formatted_json = json5.dumps(
                        data,
                        indent=2,
                        quote_keys=True,
                        trailing_commas=False,
                        ensure_ascii=False,  # 保留中文可读性
                        parse_comment=True
                    )
                    file.write(formatted_json + '\n')  # 添加换行符保持文件整洁

                print(f"成功更新构建参数：{_build_profile_path}")

            except Exception as e:
                print(f"修改构建配置失败：{str(e)}")
                # 建议添加回滚机制或错误日志记录

    def ohos_build_app(self):

        # 设置环境变量
        # env = os.environ.copy()
        # _deveco_sdk_home = os.path.join(self.args.deveco_studio, "bin")
        # # 新增 DEVECO_SDK_HOME 环境变量
        # env["DEVECO_SDK_HOME"] = self.args.deveco_studio
        # env["PATH"] = _deveco_sdk_home + os.pathsep + env["PATH"]


        _ohos_clean = self.get_ohos_build_clean_configure()

        _ohos_ohpm = self.get_ohos_ohpm_configure()

        if self.args.build_type == "hap":
            _ohos_build = self.get_ohos_build_hap_configure()
        else:
            _ohos_build = self.get_ohos_build_app_configure()

        # 进入父节点
        if os.path.exists(self.args.ohos_project):

            os.chdir(self.args.ohos_project)
            print(f"===================执行 ohos clean =======================")
            
            ret = os.system(_ohos_clean)
            if ret != 0:
                raise RuntimeError(f"ohos clean 执行失败，退出码: {ret}")

            print(f"===================执行 ohos ohpm  =======================")
            ret = os.system(_ohos_ohpm)
            if ret != 0:
                raise RuntimeError(f"ohos ohpm 执行失败，退出码: {ret}")

            print(f"===================执行 ohos build app  =======================")

            print(f"===================java version=======================")
            ## 指定java运行环境
            # os.environ["JAVA_HOME"] = self.args.java_home            
            # os.environ["PATH"] = os.path.join(self.args.java_home, "bin") + os.pathsep + os.environ["PATH"]
            # os.system("java -version")
 
            ret = os.system(_ohos_build)
            if ret != 0:
                raise RuntimeError(f"ohos build app 执行失败，退出码: {ret}")

            os.chdir("../")
        else:
            print(f"==================={self.args.ohos_project}不存在 =======================")

    def clean_output_dir(self, _dir):
        """ 删除输出目录 """
        if os.path.exists(_dir):
            print(f"===================删除  {_dir} 文件夹 =======================")
            shutil.rmtree(_dir, ignore_errors=False, onerror=lambda func, path, _: (print(f"删除失败: {path}"), os.chmod(path, 0o777), func(path)))

    def clean_main_files(self):
        """清理 main/cpp 下 除了 types 以外的所有文件"""
        target_dir = os.path.join(self.args.ohos_project, "entry/src/main/cpp")
        keep_items=["types"]  # 要保留的文件/文件夹名列表

        if os.path.exists(target_dir):
            for item in os.listdir(target_dir):
                item_path = os.path.join(target_dir, item)

                # 跳过要保留的项目
                if item in keep_items:
                    print(f"保留: {item_path}")
                    continue

                try:
                    if os.path.isfile(item_path) or os.path.islink(item_path):
                        os.remove(item_path)
                        print(f"已删除文件: {item_path}")
                    elif os.path.isdir(item_path):
                        shutil.rmtree(item_path)
                        print(f"已删除目录: {item_path}")
                except Exception as e:
                    print(f"删除失败 [{item_path}]: {str(e)}")
                    # 尝试修改权限后再次删除
                    os.chmod(item_path, 0o777)
                    if os.path.isfile(item_path):
                        os.remove(item_path)
                    else:
                        shutil.rmtree(item_path)
                    print(f"强制删除成功: {item_path}")

    def copy_main_files(self):
        """ 复制 Main 下 所有文件和文件夹 到 ohosproject/entry/src/main/cpp 下 """
        target_dir = os.path.join(self.args.ohos_project, "entry/src/main/cpp")
        source_dir = os.path.join(os.getcwd(), "Main")

        if os.path.exists(source_dir):
            self.copy_all_contents(source_dir, target_dir,without=[".git",".github",".idea",".vscode"])

    def copy_ohos_build_files(self):
        """复制 生成的 hap app 文件到 dist_path 目录"""

        if not os.path.exists(self.args.dist_path):
            os.makedirs(self.args.dist_path, exist_ok=True)

        if self.args.build_type == "hap":
            src_dir = os.path.join(self.args.ohos_project, f"entry/build/{self.args.product}/outputs/{self.args.product}")
            self.copy_files(src_dir, self.args.dist_path,post_fix=("hap"))
        else:
            src_dir = os.path.join(self.args.ohos_project, f"build/outputs/{self.args.product}")
            self.copy_files(src_dir, self.args.dist_path,post_fix=("app"))

    def copy_all_files(self, src_dir, dest_dir):
        """
        拷贝 文件 和 子文件夹
        :param src_dir:   源目录（需要复制的根目录）
        :param dest_dir:  目标目录（复制内容将存放到这里）
        """
        shutil.copytree(src_dir, dest_dir, symlinks=False, ignore=None, copy_function=shutil.copy2, ignore_dangling_symlinks=False, dirs_exist_ok=True)

    def copy_files(self,src_dir: Union[str, os.PathLike], dest_dir: Union[str, os.PathLike],post_fix):
        """
        复制指定目录下的所有库文件到目标目录
        :param src_dir: 源目录（需要搜索库文件的目录）
        :param dest_dir: 目标目录（存放库文件的目录）
        :param post_fix: 文件后缀
        """
        if not os.path.exists(dest_dir):
            os.makedirs(dest_dir, exist_ok=True)

        for root, dirs, files in os.walk(src_dir):
            for file in files:

                src_path = str(os.path.join(root, file))
                dst_path = str(os.path.join(dest_dir, file))

                if file.endswith(post_fix) :
                    shutil.copy2(src_path, dst_path)
                    print(f"Copied libs: {src_path} -> {dst_path}")


    def copy_trade_file(self):
        """ 拷贝交易文件 """


        print(f"----------------------------- 拷贝 资源文件 到 Main项目中 ---------------------------")


        # 拷贝 库文件 到 输出目录
        _lib_path = os.path.join(self.args.thr_path, "trade", "lib", self.args.arch)
        _dist_path = str(os.path.join(self.args.ohos_project,"entry/libs/arm64-v8a"))

        if not os.path.exists(_lib_path) :
            raise RuntimeError(f"不存在交易 库文件 ${_lib_path}")


        if not os.path.exists(_dist_path):
            os.makedirs(_dist_path, exist_ok=True)

        print(f"----------------------------- 拷贝 库文件 到 输出目录 ---------------------------")
        self.copy_all_files(_lib_path, _dist_path)

        print(f"----------------------------- 拷贝 cfg资源文件 到 输出目录 ---------------------------")
        # 拷贝 cfg资源文件 到 输出目录

        _dist_cfg_path = os.path.join(self.args.ohos_project,"entry/src/main/resources/rawfile/config").lower()

        _cfg_path = os.path.join(self.args.thr_path, "trade", "cfg")
        if not os.path.exists(_dist_cfg_path):
            os.makedirs(_dist_cfg_path, exist_ok=True)

        if not os.path.exists(_cfg_path) :
            raise RuntimeError(f"不存在交易 cfg 文件 ${_cfg_path}")

        self.copy_all_files(_cfg_path, _dist_cfg_path)

if __name__ == "__main__":
    try:
        args = parse_arguments()
        print(f"----------------------------- 构建 ---------------------------")
        config = BuildConfig(args)

        print(f"----------------------------- 构建 开始 ---------------------------")
        config.build_ohos_projects()
        print(f"----------------------------- 构建 拷贝第三方库到项目 ---------------------------")
        config.copy_thr_libs_files()
        print(f"----------------------------- 构建 拷贝配置到项目 ---------------------------")
        config.copy_config_files()
        
        print(f"----------------------------- 同步 Main 文件到 OHOSProject 项目  开始")
        # 清理
        config.clean_main_files()
        # # 复制
        config.copy_main_files()
        # 更新 entry/build-profile.json5 arguments的配置
        config.ohos_change_build_profile()
        # 复制 trade 资源
        config.copy_trade_file()

        print(f"----------------------------- 同步 Main 文件到 OHOSProject 项目  结束 ---------------------------")
        print(f"----------------------------- 构建 打包应用---------------------------")
        # config.ohos_build_app()
        # config.copy_ohos_build_files()

        print(f"----------------------------- 构建 结束 ---------------------------")
    except Exception as e:
        print(f"Error: {e}")
        sys.exit(1)



